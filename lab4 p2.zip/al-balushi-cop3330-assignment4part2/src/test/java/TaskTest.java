import ucf.assignments.todo;
import ucf.assignments.user;
import org.junit.Test;

import static org.junit.Assert.*;
/*
 * UCF COP3330 Fall 2021 Assignment 4 Solution
 * Copyright 2021 Taha Al balushi
 */

public class TaskTest {

    @Test
    public void getUserName() {
        user u = new user();
        u.setUserName("u1");
        String expected = "u1";
        assertEquals(expected, u.getUserName());
    }

    @Test
    public void getTitle() {
        todo task = new todo();
        task.setTitle("1");
        String expected = "1";
        assertEquals(expected, task.getTitle());
    }



    @Test
    public void getStatus() {
        todo task = new todo();
        task.setStatus("Working");
        String expected = "Working";
        assertEquals(expected, task.getStatus());

    }



}