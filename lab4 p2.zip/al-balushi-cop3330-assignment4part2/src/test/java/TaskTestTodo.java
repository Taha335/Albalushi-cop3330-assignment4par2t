import ucf.assignments.todo;
import org.junit.Test;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;

import static org.junit.Assert.*;
/*
 * UCF COP3330 Fall 2021 Assignment 4 Solution
 * Copyright 2021 Taha Al balushi
 */

public class TaskTestTodo {
    @Test
    public void getTitle() {
        todo task = new todo();
        task.setTitle("1");
        String expected = "1";
        assertEquals(expected, task.getTitle());
    }

    @Test
    public void getStatus() {
        todo task = new todo();
        task.setStatus("Working");
        String expected = "Working";
        assertEquals(expected, task.getStatus());

    }

    @Test
    public void getDesc() {
        todo task = new todo();
        task.setDesc("Job next month");
        String expected = "Job next month";
        assertEquals(expected, task.getDesc());
    }


    @Test
    public void createTodo() throws IOException, ParseException {
        todo task = new todo();
        task.setId(110);
        task.setDesc("Job next month");
        task.setUserName("David");
        task.setTodoDate(new Date("2021-11-15"));
        task.createTodo(task);
        int expected = 110;
        assertEquals(expected, task.getId());
    }

}