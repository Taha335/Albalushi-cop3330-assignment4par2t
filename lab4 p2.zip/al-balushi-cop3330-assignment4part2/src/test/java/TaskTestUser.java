import ucf.assignments.user;
import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.*;
/*
 * UCF COP3330 Fall 2021 Assignment 4 Solution
 * Copyright 2021 Taha Al balushi
 */

public class TaskTestUser {

    @Test
    public void getUserName() {
        user u = new user();
        u.setUserName("u1");
        String expected = "u1";
        assertEquals(expected, u.getUserName());
    }

    @Test
    public void getFirstName() {
        user task = new user();

        task.setFirstName("David");
        String expected = "David";
        assertEquals(expected, task.getFirstName());
    }

    @Test
    public void getLastName() {
        user task = new user();

        task.setLastName("Btton");
        String expected = "Btton";
        assertEquals(expected, task.getLastName());

    }

    @Test
    public void loginFail() {
        user task = new user();
        task.setUserName("Btton");
        task.setPassword("Btton");
        String expected = null;
        assertEquals(expected, task.isLogingSuceess("Btton","Btton"));

    }

    @Test
    public void createUser() throws IOException {
        user task = new user();
        task.setUserName("Btton");
        task.setPassword("Btton");
        task.createUser(task);
        assertEquals(task.getUserName(), task.getUserInfo("Btton").getUserName());
    }

}