package ucf.assignments;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

/*
 * UCF COP3330 Fall 2021 Assignment 4 Solution
 * Copyright 2021 Taha Al balushi
 */
public class listTodos {
    private JPanel listPanel;
    private JButton btnAddTodoButton;
    private JTable jTableListTodo;
    private JButton editButton;
    private JTextField txtUserName;
    private JTextField txtName;
    private JScrollPane jScrollPanetb;
    private JButton btnDelete;
    private JButton btnclearAllButton;
    private user usr;

    public listTodos() {
        btnAddTodoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                usr = new user().getUserInfo(txtUserName.getText());
                new addNewTodo().showAddNewTodo(usr);
            }
        });
        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int column = 0;
                int row = jTableListTodo.getSelectedRow();
                String id = jTableListTodo.getModel().getValueAt(row, column).toString();
                new editTodo().showEditTodo(id);
            }
        });
        btnDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int column = 0;
                int row = jTableListTodo.getSelectedRow();
                String id = jTableListTodo.getModel().getValueAt(row, column).toString();
                try {
                    new todo().deleteTodo(id);
                    JOptionPane.showMessageDialog(null, "Delete successfully");
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                } catch (ParseException parseException) {
                    parseException.printStackTrace();
                }

            }
        });
        btnclearAllButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new todo().clearAllTodo(txtUserName.getText());
                    JOptionPane.showMessageDialog(null, "Clear successfully");
                    JComponent comp = (JComponent) e.getSource();
                    Window win = SwingUtilities.getWindowAncestor(comp);
                    win.dispose();
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                } catch (ParseException parseException) {
                    parseException.printStackTrace();
                }
            }
        });
    }

    public void showListTodos(user u) {
        JFrame frame = new JFrame("List Todos Form");
        frame.setPreferredSize(new Dimension(640, 480));
        listTodos f = new listTodos();
        f.txtUserName.setText(u.getUserName());
        f.txtUserName.setVisible(false);
        f.txtName.setText(u.getFirstName() + " - " + u.getLastName());
        usr = new user(u.getUserName(), u.getLastName(), u.getFirstName(), u.getPassword());

        List<String> columns = new ArrayList<String>();
        List<String[]> values = new ArrayList<String[]>();

        columns.add("id");
        columns.add("Title");
        columns.add("Desc");
        columns.add("Status");
        columns.add("Date");

        List<todo> todos = null;
        try {
            todos = new todo().readFileTodoList("");
        } catch (IOException e) {
            System.out.println(e);
        }
        for (todo td : todos
        ) {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            String date1format = formatter.format(td.getTodoDate());
            if (u.getUserName().equalsIgnoreCase(td.getUserName()))
                values.add(new String[]{String.valueOf(td.getId()), td.getTitle(), td.getDesc(), td.getStatus(), date1format});
        }

        TableModel tableModel = new DefaultTableModel(values.toArray(new Object[][]{}), columns.toArray());

        f.jTableListTodo = new JTable(tableModel);
        f.jTableListTodo.setFillsViewportHeight(true);
        f.jScrollPanetb.setViewportView(f.jTableListTodo);


        frame.setContentPane(f.listPanel);
        frame.pack();
        frame.setVisible(true);


    }

}
