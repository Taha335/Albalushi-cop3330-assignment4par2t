package ucf.assignments;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

/*
 * UCF COP3330 Fall 2021 Assignment 4 Solution
 * Copyright 2021 Taha Al balushi
 */
public class App {
    private JPanel panelMain;
    private JButton registerButton;
    private JButton loginButton;


    public App() {
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                new loginForm().showLoginForm();
            }
        });
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                new registerForm().showRegisterForm();
            }
        });
    }

    public static void main(String[] args) throws IOException {
        JFrame frame = new JFrame("App");
        frame.setContentPane(new App().panelMain);
        frame.setPreferredSize(new Dimension(640, 480));
        //frame.setContentPane(new JLabel(new ImageIcon(ImageIO.read(new File("todobackground.jpg")))));
        //background.setBackground(new ImageIcon(ImageIO.read(new File("todobackground.jpg"))));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
