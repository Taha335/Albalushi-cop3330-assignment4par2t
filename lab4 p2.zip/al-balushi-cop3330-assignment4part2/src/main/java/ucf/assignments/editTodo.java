package ucf.assignments;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/*
 * UCF COP3330 Fall 2021 Assignment 4 Solution
 * Copyright 2021 Taha Al balushi
 */
public class editTodo {
    private JPanel edittodoPanel;
    private JTextField txtTodoTitle;
    private JTextField txtTodoDesc;
    private JComboBox cbTodoStatus;
    private JTextField txtDate;
    private JButton updateButton;
    private JTextField txtId;
    private JTextField txtUserName;

    public editTodo() {
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                todo td = new todo();
                td.setId(Integer.valueOf(txtId.getText()));
                td.setStatus(cbTodoStatus.getSelectedItem().toString());
                String todoDate = txtDate.getText();
                SimpleDateFormat DateFor = new SimpleDateFormat("yyyy-MM-dd");
                Date date1 = null;
                try {
                    date1 = DateFor.parse(todoDate);
                } catch (ParseException parseException) {
                    parseException.printStackTrace();
                }
                td.setTodoDate(date1);
                td.setTitle(txtTodoTitle.getText());
                td.setDesc(txtTodoDesc.getText());
                td.setUserName(txtUserName.getText());
                try {
                    new todo().editTodo(td);
                    JOptionPane.showMessageDialog(null, "Edit successfully");
                    JComponent comp = (JComponent) e.getSource();
                    Window win = SwingUtilities.getWindowAncestor(comp);
                    win.dispose();
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                } catch (ParseException parseException) {
                    parseException.printStackTrace();
                }
            }
        });
    }

    public void showEditTodo(String id) {
        todo td = new todo();
        td = td.getTodoInfo(id);
        System.out.println(td.getDesc());
        editTodo f = new editTodo();
        f.txtTodoTitle.setText(td.getTitle());
        f.txtTodoDesc.setText(td.getDesc());
        f.cbTodoStatus.setSelectedItem(td.getStatus());
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String date1format = formatter.format(td.getTodoDate());
        f.txtDate.setText(date1format);
        f.txtId.setVisible(false);
        f.txtId.setText(id);
        f.txtUserName.setText(td.getUserName());
        f.txtUserName.setVisible(false);

        JFrame frame = new JFrame("Edit Todo Form");
        frame.setPreferredSize(new Dimension(640, 480));
        frame.setContentPane(f.edittodoPanel);
        frame.pack();
        frame.setVisible(true);
    }
}
