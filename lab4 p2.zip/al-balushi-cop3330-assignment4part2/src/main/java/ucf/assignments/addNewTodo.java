package ucf.assignments;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
/*
 * UCF COP3330 Fall 2021 Assignment 4 Solution
 * Copyright 2021 Taha Al balushi
 */

public class addNewTodo {
    private JPanel addnewtodoPanel;
    private JTextField txtTodoTitle;
    private JTextField txtTodoDesc;
    private JComboBox cbTodoStatus;
    private JTextField txtDate;
    private JButton addButton;
    private JLabel meesg;
    private JTextField txtName;
    private JTextField txtUserName;
    private user usr;

    public addNewTodo() {
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int Id = (int) (new Date().getTime()/1000);
                String todoTitle = txtTodoTitle.getText();
                String todoDesc = txtTodoDesc.getText();
                String todoDate = txtDate.getText();
                String todoStatus = cbTodoStatus.getSelectedItem().toString ();
                todo tod = new todo();
                tod.setId(Id);
                tod.setTitle(todoTitle);
                tod.setDesc(todoDesc);
                tod.setStatus(todoStatus);
                tod.setUserName(txtUserName.getText());
                try {
                    SimpleDateFormat DateFor = new SimpleDateFormat("yyyy-MM-dd");
                    Date date1 = DateFor.parse(todoDate);
                    tod.setTodoDate(date1);
                    tod.createTodo(tod);
                    JOptionPane.showMessageDialog(null,"add successfully");

                } catch (Exception ex) {
                    ex.printStackTrace();
                    meesg.setText(ex.toString());
                    JOptionPane.showMessageDialog(null,ex);
                }

            }
        });
    }

    public void showAddNewTodo(user u){
        JFrame frame = new JFrame("New Todo Form");
        addNewTodo f = new addNewTodo();
        f.txtName.setText(u.getFirstName() +" - " +u.getLastName());
        f.txtUserName.setText(u.getUserName());
        f.txtUserName.setVisible(false);
        frame.setPreferredSize( new Dimension( 640, 480 ) );
        frame.setContentPane(f.addnewtodoPanel);
        frame.pack();
        frame.setVisible(true);
    }

}
