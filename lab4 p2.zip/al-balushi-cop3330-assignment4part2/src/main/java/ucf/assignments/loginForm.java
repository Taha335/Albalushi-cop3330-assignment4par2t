package ucf.assignments;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.List;

/*
 * UCF COP3330 Fall 2021 Assignment 4 Solution
 * Copyright 2021 Taha Al balushi
 */
public class loginForm {
    private JPanel loginPanel;
    private JTextField txtUserName;
    private JPasswordField txtPassword;
    private JButton btnLogin;
    private JLabel message;

    public loginForm() {
        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String username = txtUserName.getText();
                String password = txtPassword.getText();
                user u = new user().isLogingSuceess(username, password);
                if (u != null) {

                    new listTodos().showListTodos(u);
                } else {
                    message.setText("Login False");
                }

            }
        });
    }

    public void showLoginForm() {
        JFrame frame = new JFrame("Login Form");
        frame.setPreferredSize(new Dimension(640, 480));
        frame.setContentPane(new loginForm().loginPanel);
        frame.pack();
        frame.setVisible(true);
    }
}
