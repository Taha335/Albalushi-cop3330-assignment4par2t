package ucf.assignments;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

/*
 * UCF COP3330 Fall 2021 Assignment 4 Solution
 * Copyright 2021 Taha Al balushi
 */
public class registerForm {
    private JPanel registerPanel;
    private JTextField txtFirstName;
    private JTextField txtLastName;
    private JTextField txtUserName;
    private JPasswordField txtPassword;
    private JButton btnRegister;
    private JLabel lbTodoApp;
    private JLabel userRegister;
    private JLabel FirstName;
    private JLabel lastName;
    private JLabel pass;
    private JLabel uName;


    public registerForm() {
        btnRegister.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String firstName = txtFirstName.getText();
                String lastName = txtLastName.getText();
                String userName = txtUserName.getText();
                String password = txtPassword.getText();
                user u = new user(userName, lastName, firstName, password);
                try {
                    u.createUser(u);
                    JOptionPane.showMessageDialog(null, "Register successfully");
                    JComponent comp = (JComponent) e.getSource();
                    Window win = SwingUtilities.getWindowAncestor(comp);
                    win.dispose();
                } catch (IOException ioException) {
                    JOptionPane.showMessageDialog(null, "register failed");
                    ioException.printStackTrace();
                }
            }
        });
    }

    public void showRegisterForm() {
        JFrame frame = new JFrame("Register Form");
        frame.setPreferredSize(new Dimension(640, 480));
        frame.setContentPane(new registerForm().registerPanel);
        frame.pack();
        frame.setVisible(true);
    }

}
