package ucf.assignments;

import com.opencsv.CSVWriter;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/*
 * UCF COP3330 Fall 2021 Assignment 4 Solution
 * Copyright 2021 Taha Al balushi
 */
public class todo {
    int id;
    String title;
    String desc;
    String status;
    Date todoDate;
    String userName;

    public todo() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getTodoDate() {
        return todoDate;
    }

    public void setTodoDate(Date todaoDate) {
        this.todoDate = todaoDate;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public todo(int id, String title, String desc, String status, Date todoDate, String userName) {
        this.id = id;
        this.title = title;
        this.desc = desc;
        this.status = status;
        this.todoDate = todoDate;
        this.userName = userName;
    }

    public void createTodo(todo tod) throws IOException, ParseException {
        String csv = "TodoList.csv";
        CSVWriter writer = null;
        writer = new CSVWriter(new FileWriter(csv, true));
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String date1format = formatter.format(tod.getTodoDate());
        String todo = tod.getId() + "," + tod.getTitle() + "," + tod.getDesc() + "," + tod.getStatus() + ","
                + date1format + "," + tod.getUserName();
        String[] record = todo.split(",");
        writer.writeNext(record);
        writer.close();

    }

    public List<todo> readFileTodoList(String fileName) throws IOException {
        if (fileName.isEmpty()) {
            fileName = "TodoList.csv";
        }
        List<todo> result = new ArrayList<todo>();
        BufferedReader br = new BufferedReader(new FileReader(new File(fileName)));
        try {
            String line = null;
            // Run through following lines
            while ((line = br.readLine()) != null) {
                // Break line into entries using comma
                String[] items = line.split(",");
                try {
                    todo tod = new todo();
                    tod.setId(Integer.valueOf(removeFirstandLast(items[0])));
                    tod.setTitle(removeFirstandLast(items[1]));
                    tod.setDesc(removeFirstandLast(items[2]));
                    tod.setStatus(removeFirstandLast(items[3]));
                    String sDate1 = removeFirstandLast(items[4]);
                    tod.setUserName(removeFirstandLast(items[5]));
                    SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
                    Date date1 = formatter1.parse(sDate1);
                    tod.setTodoDate(date1);
                    result.add(tod);
                } catch (ArrayIndexOutOfBoundsException | NumberFormatException | NullPointerException | ParseException e) {
                    // Caught errors indicate a problem with data format -> Print warning and continue
                    System.out.println("readFileTodoList Invalid line: " + line + e.toString());
                }
            }
            return result;
        } finally {
            br.close();
        }
    }


    public String removeFirstandLast(String str) {

        // Removing first and last character
        // of a string using substring() method
        str = str.substring(1, str.length() - 1);
        // Return the modified string
        return str;
    }

    public todo getTodoInfo(String id) {
        List<todo> todos = null;
        try {
            todos = readFileTodoList("");
            System.out.println("List<todo> " + todos.size());
        } catch (IOException e) {
            System.out.println(e);
            return null;
        }
        return todos.stream()
                .filter(td -> id.equals(String.valueOf(td.getId())))
                .findAny()
                .orElse(null);
    }

    public void editTodo(todo td) throws IOException, ParseException {
        List<todo> todos = null;
        String fileName = "TodoList.csv";
        try {
            todos = readFileTodoList("");
            System.out.println("List<todo> " + todos.size());
        } catch (IOException e) {
            System.out.println(e);
        }
        ListIterator<todo> iterator = todos.listIterator();
        while (iterator.hasNext()) {
            todo s = iterator.next();
            if (s.getId() == td.getId()) {
                iterator.set(td);
            }
        }
        File fileToMove = new File(fileName);
        String fileNamebk = fileName + "." + String.valueOf(todos.size()) + ".bak";
        fileToMove.renameTo(new File(fileNamebk));

        File myObj = new File(fileName);
        if (myObj.delete()) {
            System.out.println("Deleted the file: " + myObj.getName());
        } else {
            System.out.println("Failed to delete the file.");
        }


        for (todo t : todos
        ) {
            createTodo(t);
        }
    }

    public void deleteTodo(String id) throws IOException, ParseException {
        todo td = getTodoInfo(id);
        List<todo> todos = null;
        String fileName = "TodoList.csv";
        try {
            todos = readFileTodoList("");
            System.out.println("List<todo> " + todos.size());
        } catch (IOException e) {
            System.out.println(e);
        }
        ListIterator<todo> iterator = todos.listIterator();
        while (iterator.hasNext()) {
            todo s = iterator.next();
            if (s.getId() == td.getId()) {
                iterator.remove();
            }
        }
        File fileToMove = new File(fileName);
        String fileNamebk = fileName + "." + String.valueOf(todos.size()) + ".bak";
        fileToMove.renameTo(new File(fileNamebk));

        File myObj = new File(fileName);
        if (myObj.delete()) {
            System.out.println("Deleted the file: " + myObj.getName());
        } else {
            System.out.println("Failed to delete the file.");
        }

        for (todo t : todos
        ) {
            createTodo(t);
        }
    }

    public void clearAllTodo(String userName) throws IOException, ParseException {
        List<todo> todos = null;
        String fileName = "TodoList.csv";
        try {
            todos = readFileTodoList("");
            System.out.println("List<todo> " + todos.size());
        } catch (IOException e) {
            System.out.println(e);
        }
        ListIterator<todo> iterator = todos.listIterator();
        while (iterator.hasNext()) {
            todo s = iterator.next();
            if (s.getUserName().equals(userName)) {
                iterator.remove();
            }
        }
        File fileToMove = new File(fileName);
        String fileNamebk = fileName + "." + String.valueOf(todos.size()) + ".bak";
        fileToMove.renameTo(new File(fileNamebk));

        File myObj = new File(fileName);
        if (myObj.delete()) {
            System.out.println("Deleted the file: " + myObj.getName());
        } else {
            System.out.println("Failed to delete the file.");
        }
        for (todo t : todos
        ) {
            createTodo(t);
        }
    }


}
